#' Helper functions

extract_test_pred <- function(x) {
  pred <- x$data$response
  return(pred)
}
